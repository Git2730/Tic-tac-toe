#include <iostream>
#include <vector>
#include <stack>
#include <cstdlib>
#include <ctime>
#include <limits>
using namespace std;

struct Game {
    vector<vector<char>> board;
    int turn; // 1 for Player-1 (X), 0 for Player-2 or AI (O)
    stack<pair<int, int>> moveHistory;
    bool vsAI;
    string difficulty;

    Game(bool modeAI, string level) {
        board = vector<vector<char>>(3, vector<char>(3, '-'));
        turn = 1;
        vsAI = modeAI;
        difficulty = level;
        srand(time(0));
    }

    void display() {
        cout << "\n";
        for (int i = 0; i < 3; ++i) {
            cout << " ";
            for (int j = 0; j < 3; ++j) {
                cout << board[i][j];
                if (j < 2) cout << " | ";
            }
            cout << "\n";
            if (i < 2) cout << "---+---+---\n";
        }
        cout << "\n";
    }

    bool checkWin(char player) {
        for (int i = 0; i < 3; ++i) {
            if (board[i][0] == player && board[i][1] == player && board[i][2] == player)
                return true;
            if (board[0][i] == player && board[1][i] == player && board[2][i] == player)
                return true;
        }
        if (board[0][0] == player && board[1][1] == player && board[2][2] == player)
            return true;
        if (board[0][2] == player && board[1][1] == player && board[2][0] == player)
            return true;

        return false;
    }

    bool isFull() {
        for (auto& row : board)
            for (char cell : row)
                if (cell == '-') return false;
        return true;
    }

    bool filled(int r, int c) {
        return board[r][c] != '-';
    }

    void makeMove(int r, int c, char player) {
        board[r][c] = player;
        moveHistory.push({r, c});
    }

    int minimax(bool isMax) {
        if (checkWin('O')) return 10;
        if (checkWin('X')) return -10;
        if (isFull()) return 0;

        if (isMax) {
            int best = -1e9;
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j)
                    if (board[i][j] == '-') {
                        board[i][j] = 'O';
                        best = max(best, minimax(false));
                        board[i][j] = '-';
                    }
            return best;
        } else {
            int best = 1e9;
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j)
                    if (board[i][j] == '-') {
                        board[i][j] = 'X';
                        best = min(best, minimax(true));
                        board[i][j] = '-';
                    }
            return best;
        }
    }

    pair<int, int> bestMove() {
        if (difficulty == "easy") {
            vector<pair<int, int>> options;
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j)
                    if (board[i][j] == '-') options.push_back({i, j});
            if (!options.empty()) {
                int idx = rand() % options.size();
                return options[idx];
            }
        }

        int bestVal = -1e9;
        pair<int, int> move = {-1, -1};
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                if (board[i][j] == '-') {
                    board[i][j] = 'O';
                    int score = minimax(false);
                    board[i][j] = '-';
                    if (score > bestVal) {
                        bestVal = score;
                        move = {i, j};
                    }
                }
        return move;
    }
};

int main() {
    string modeInput, difficultyInput;
    bool vsAI = false;
    string difficulty = "easy";

    cout << "Tic-Tac-Toe\n";
    cout << "-----------\n";
    cout << "1. Single Player (vs AI)\n";
    cout << "2. Two Player\n";
    cout << "Select mode (1 or 2): ";
    getline(cin, modeInput);

    if (modeInput == "1") {
        vsAI = true;
        cout << "\nSelect difficulty:\n";
        cout << "1. Easy\n";
        cout << "2. Hard\n";
        cout << "Choose (1 or 2): ";
        getline(cin, difficultyInput);
        if (difficultyInput == "2") difficulty = "hard";

        cout << "\nYou are X. AI is O.\n";
        cout << "Mode: " << (difficulty == "easy" ? "Easy" : "Hard") << "\n";
    } else {
        cout << "\nPlayer-1: X\nPlayer-2: O\n";
    }

    while (true) {
        Game g(vsAI, difficulty);
        cout << "\n--- New Game ---\n";

        while (true) {
            g.display();

            if (g.turn == 1 || !g.vsAI) {
                cout << "Player-" << (g.turn + 1) << " (" << (g.turn == 1 ? 'X' : 'O') << ") turn\n";
                int r, c;
                cout << "Row (1-3): "; cin >> r;
                cout << "Col (1-3): "; cin >> c;
                r--; c--;

                if (r < 0 || r > 2 || c < 0 || c > 2 || g.filled(r, c)) {
                    cout << "Invalid move. Try again.\n";
                    continue;
                }

                g.makeMove(r, c, g.turn == 1 ? 'X' : 'O');
            } else {
                cout << "AI is making its move...\n";
                auto [r, c] = g.bestMove();
                g.makeMove(r, c, 'O');
                cout << "AI played at: (" << r + 1 << ", " << c + 1 << ")\n";
            }

            if (g.checkWin('X')) {
                g.display();
                cout << (g.vsAI ? "\nYou win!\n" : "\nPlayer-1 wins!\n");
                break;
            }

            if (g.checkWin('O')) {
                g.display();
                cout << (g.vsAI ? "\nAI wins!\n" : "\nPlayer-2 wins!\n");
                break;
            }

            if (g.isFull()) {
                g.display();
                cout << "\nIt's a draw.\n";
                break;
            }

            g.turn = (g.turn + 1) % 2;
        }

        string playAgain;
        cout << "\nPlay again? (y/n): ";
        cin >> playAgain;
        if (playAgain != "y" && playAgain != "Y") {
            cout << "Thanks for playing!\n";
            break;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    return 0;
}
